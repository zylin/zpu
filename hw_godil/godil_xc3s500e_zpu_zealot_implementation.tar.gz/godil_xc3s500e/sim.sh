#!/bin/sh

echo "###############"
echo "compile zpu lib"
vlib zpu
vcom -quiet -work zpu ../../zealot/roms/hello_dbram.vhdl
vcom -quiet -work zpu ../../zealot/roms/hello_bram.vhdl
#vcom -quiet -work zpu ../../zealot/roms/dmips_dbram.vhdl
#vcom -quiet -work zpu ../../zealot/roms/dmips_bram.vhdl
vcom -quiet -work zpu ../../zealot/roms/rom_pkg.vhdl
vcom -quiet -work zpu ../../zealot/zpu_pkg.vhdl
vcom -quiet -work zpu ../../zealot/zpu_small.vhdl
vcom -quiet -work zpu ../../zealot/zpu_medium.vhdl
vcom -quiet -work zpu ../../zealot/helpers/zpu_small1.vhdl
vcom -quiet -work zpu ../../zealot/helpers/zpu_med1.vhdl
vcom -quiet -work zpu ../../zealot/devices/txt_util.vhdl
vcom -quiet -work zpu ../../zealot/devices/phi_io.vhdl
vcom -quiet -work zpu ../../zealot/devices/timer.vhdl
vcom -quiet -work zpu ../../zealot/devices/rx_unit.vhdl
vcom -quiet -work zpu ../../zealot/devices/tx_unit.vhdl
vcom -quiet -work zpu ../../zealot/devices/br_gen.vhdl
vcom -quiet -work zpu ../../zealot/devices/trace.vhdl

echo "################"
echo "compile work lib"
vlib work
vcom top.vhd
vcom top_tb.vhd

#echo "###################"
#echo "start simulator gui"
#vsim -gui top_tb

